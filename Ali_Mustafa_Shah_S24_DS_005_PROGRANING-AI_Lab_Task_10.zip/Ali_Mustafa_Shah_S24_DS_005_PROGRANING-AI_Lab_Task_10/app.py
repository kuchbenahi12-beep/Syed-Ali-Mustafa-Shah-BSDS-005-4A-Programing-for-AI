from flask import Flask, render_template, request, jsonify
app = Flask(__name__)
RESPONSES = {
    "hi": "Hello! Welcome to University Admission Chatbot 👋 How can I help you?",
    "hello": "Hi there! Ask me anything about admissions, programs, or deadlines.",
    "programs": "We offer:\n• BS Computer Science\n• BS Data Science\n• BS Software Engineering\n• BS Artificial Intelligence\n• BBA\n• BS Accounting & Finance",
    "fee": "Fee structure (per semester):\n• BS Programs: 120,000–140,000 PKR\n• Discount available on merit & need basis",
    "deadline": "Fall 2026 admission deadline: 30 June 2026\nSpring 2026: 30 November 2025",
    "eligibility": "Minimum 50% in Intermediate/FSc/A-Levels\nEntry test is mandatory",
    "scholarship": "Yes! We offer:\n• 100% Merit Scholarship (90%+ marks)\n• 50–75% Need-based\n• Kinship & Sports scholarships",
    "hostel": "Yes, separate hostels for boys & girls.\nMonthly charges: 15,000–20,000 PKR",
    "location": "Main Campus: Johar Town, Lahore\nSecond Campus: Raiwind Road",
    "contact": "Phone: 042-111-222-333\nEmail: admissions@university.edu.pk",
    "bye": "Thank you for chatting! Best of luck with your admission ✨",
    "default": "Sorry, I don't understand that. You can ask about programs, fees, deadlines, scholarships, hostel, etc."
}
@app.route("/")
def home():
    return render_template("index.html")
@app.route("/ask", methods=["POST"])
def ask():
    message = request.json.get("message", "").lower().strip()    
    for key in RESPONSES:
        if key in message:
            reply = RESPONSES[key]
            break
    else:
        reply = RESPONSES["default"]
    
    return jsonify({"reply": reply})
if __name__ == "__main__":
    app.run(debug=True)