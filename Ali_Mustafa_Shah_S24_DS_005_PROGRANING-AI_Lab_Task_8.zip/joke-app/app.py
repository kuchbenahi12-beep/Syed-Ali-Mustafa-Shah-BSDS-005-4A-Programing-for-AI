from flask import Flask, render_template
import requests

app = Flask(__name__)

HEADERS = {"Accept": "application/json"}

@app.route("/")
def home():
    response = requests.get("https://icanhazdadjoke.com/", headers=HEADERS)
    joke = response.json()["joke"]
    return render_template("index.html", joke=joke)

@app.route("/new")
def new_joke():
    response = requests.get("https://icanhazdadjoke.com/", headers=HEADERS)
    joke = response.json()["joke"]
    return render_template("index.html", joke=joke)

if __name__ == "__main__":
    app.run(debug=True)