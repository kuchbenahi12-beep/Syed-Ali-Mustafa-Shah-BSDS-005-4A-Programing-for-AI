import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import nltk
from nltk.corpus import stopwords
import string

nltk.download('stopwords')
url = "https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial/master/data/sms.tsv"
df = pd.read_csv(url, sep='\t', header=None, names=['label', 'message'])

print("Dataset loaded!")
print(df.head())
print(f"Total messages: {len(df)}")
print(f"Spam: {len(df[df.label=='spam'])} | Ham: {len(df[df.label=='ham'])}")

def preprocess_text(text):
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = text.lower()
    stop_words = set(stopwords.words('english'))
    words = text.split()
    words = [word for word in words if word not in stop_words]
    return ' '.join(words)

df['clean_message'] = df['message'].apply(preprocess_text)

vectorizer = TfidfVectorizer(max_features=3000)
X = vectorizer.fit_transform(df['clean_message'])
y = df['label']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
classifier = MultinomialNB()
classifier.fit(X_train, y_train)
y_pred = classifier.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print(f"\nAccuracy: {accuracy*100:.2f}%")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

def predict_spam(text):
    cleaned = preprocess_text(text)
    vectorized = vectorizer.transform([cleaned])
    prediction = classifier.predict(vectorized)[0]
    prob = classifier.predict_proba(vectorized)[0]
    confidence = max(prob)
    return prediction, confidence

test_messages = [
    "Free entry in 2 a wkly comp to win FA Cup final tickets!",
    "Hey, are we still meeting for lunch tomorrow?",
    "WINNER!! You have won $1000 cash prize. Call now!",
    "Sorry I'll call later"
]

print("\n" + "="*50)
print("custom message testing")
print("="*50)
for msg in test_messages:
    result, conf = predict_spam(msg)
    print(f"massage : {msg}")
    print(f"Result : {result.upper()} (confidence: {conf:.2%})\n")