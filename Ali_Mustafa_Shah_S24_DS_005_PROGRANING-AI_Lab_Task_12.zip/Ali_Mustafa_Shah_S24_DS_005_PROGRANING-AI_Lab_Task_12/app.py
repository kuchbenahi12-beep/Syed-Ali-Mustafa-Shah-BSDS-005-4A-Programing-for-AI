from flask import Flask, render_template, request, jsonify
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import os

app = Flask(__name__)
print("Loading MiniLM model...")
model = SentenceTransformer('all-MiniLM-L6-v2')

with open("data.txt", "r", encoding="utf-8") as f:
    text = f.read()

chunks = [line.strip() for line in text.split('\n') if line.strip()]
print(f"Loaded {len(chunks)} knowledge chunks")
print("Creating embeddings...")

embeddings = model.encode(chunks)
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(embeddings))
print("FAISS index ready!")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    user_question = request.json.get("question", "").strip()
    if not user_question:
        return jsonify({"answer": "Please ask a question!"})

    question_embedding = model.encode([user_question])
    D, I = index.search(np.array(question_embedding), k=3)
    context = "\n".join([chunks[i] for i in I[0] if i != -1])    
    answer = f"Based on university records:\n{context}"
    return jsonify({"answer": answer, "sources": [chunks[i] for i in I[0] if i != -1]})

if __name__ == "__main__":
    app.run(debug=True)

