from flask import Flask, render_template, Response
import cv2
from deepface import DeepFace
import numpy as np

app = Flask(__name__)
camera = cv2.VideoCapture(0)

# Load emotion model once (improves speed)
DeepFace.build_model("Emotion")

def generate_frames():
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +
                                         "haarcascade_frontalface_default.xml")

    while True:
        success, frame = camera.read()
        if not success:
            break

        try:
            result = DeepFace.analyze(
                frame,
                actions=['emotion'],
                enforce_detection=False,
                silent=True
            )

            emotion = result[0]['dominant_emotion']

            # Detect faces for drawing box
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 165, 0), 3)
                cv2.putText(frame, emotion.capitalize(), (x, y - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 3)

        except Exception as e:
            print("Error:", e)

        ret, buffer = cv2.imencode(".jpg", frame)
        frame = buffer.tobytes()

        yield (b"--frame\r\n"
               b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/video")
def video():
    return Response(generate_frames(),
                    mimetype="multipart/x-mixed-replace; boundary=frame")

if __name__ == "__main__":
    app.run(debug=True)
